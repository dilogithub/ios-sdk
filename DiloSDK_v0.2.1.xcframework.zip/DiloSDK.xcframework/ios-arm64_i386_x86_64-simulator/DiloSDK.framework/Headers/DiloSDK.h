//
//  DiloSDK.h
//  DiloSDK
//
//  Created by Kangaroo on 2021/02/18.
//

#import <Foundation/Foundation.h>

//! Project version number for DiloSDK.
FOUNDATION_EXPORT double DiloSDKVersionNumber;

//! Project version string for DiloSDK.
FOUNDATION_EXPORT const unsigned char DiloSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DiloSDK/PublicHeader.h>


